package com.tmobile.poc.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.tmobile.poc.common.IConstants;
import com.tmobile.poc.vo.BillingAccountSummaryVO;
import com.tmobile.poc.vo.CustomerVO;

@Service
public class BillingAccountService {

	public static final Map<String, CustomerVO> customerMap = new HashMap<String, CustomerVO>();
	public static final Map<Integer, BillingAccountSummaryVO> accountMap = new HashMap<Integer, BillingAccountSummaryVO>();

	@Autowired
	private RestTemplate restTemplate;

	@Value("${customerInfo.uri}")
	private String customerInfoUri;

	/**
	 * Method is used for getting the Billing Account Balances.
	 * 
	 * @param phoneNumber
	 * @return
	 */
	public BillingAccountSummaryVO getAccountBalance(String phoneNumber) {
		CustomerVO customer = customerMap.get(phoneNumber);
		if (customer == null) {
			customer = getCustomerInfo(phoneNumber);
		}
		return accountMap.get(customer.getCustomerId());
	}

	private CustomerVO getCustomerInfo(String phoneNumber) {
		CustomerVO customer = null;
		BillingAccountSummaryVO account = null;
		try {
			customer = restTemplate.getForObject(customerInfoUri + phoneNumber, CustomerVO.class);
			account = accountMap.get(customer.getCustomerId());
			updateMaps(customer, account);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return customerMap.get(phoneNumber);
	}

	private void updateMaps(CustomerVO customer, BillingAccountSummaryVO account) {
		updateCustomerMap(customer);
		updateAccountMap(customer, account);
	}

	private void updateCustomerMap(CustomerVO customer) {
		customerMap.put(customer.getPhoneNumber(), customer);
	}

	private void updateAccountMap(CustomerVO customer, BillingAccountSummaryVO account) {
		if (account == null) {
			account = new BillingAccountSummaryVO();
			account.setAcctId(accountMap.size() + 1);
			account.setCustomerId(customer.getCustomerId());
			account.setPhoneNumber(customer.getPhoneNumber());
			account.setCurrentBal(0.00);
			// account.setStatementBalance(0.00);
			account.setUnbilledCredits(0.00);
			account.setUnbilledDebits(0.00);
			account.setUnbilledPayments(0.00);
		}
		accountMap.put(account.getCustomerId(), account);
	}

	/**
	 * Method used to update the Balances by Customer Id.
	 * 
	 * @param customerId
	 * @param transAmt
	 * @param transType
	 * @return
	 */

	public BillingAccountSummaryVO updateBalances(Integer customerId, Double transAmt, Integer transType) {
		BillingAccountSummaryVO account = accountMap.get(customerId);
		if (account != null) {
			switch (transType) {
			case IConstants.DEBIT_ADJUSTMENT:
				account.setUnbilledDebits(account.getUnbilledDebits() + transAmt);
				account.setCurrentBal(account.getCurrentBal() + transAmt);
				break;
			case IConstants.CREDIT_ADJUSTMENT:
				account.setUnbilledCredits(account.getUnbilledCredits() + transAmt);
				account.setCurrentBal(account.getCurrentBal() - transAmt);
				break;
			case IConstants.PAYMENT:
				account.setUnbilledCredits(account.getUnbilledPayments() + transAmt);
				account.setCurrentBal(account.getCurrentBal() - transAmt);
				break;
			}
			accountMap.put(customerId, account);
		}
		return account;

	}

}
