package com.tmobile.poc.processor;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.tmobile.poc.vo.PaymentDTO;
import com.tmobile.poc.vo.PaymentVO;

@Service
public class PaymentService {

	public static final Map<Integer, PaymentDTO> paymentMap = new HashMap<Integer, PaymentDTO>();
	private static final Logger logger = Logger.getLogger(PaymentService.class);

	@Value("${billingAccountURI}")
	private String billingAccountURI;

	@Autowired
	private RestTemplate restTemplate;

	public String processPayment(PaymentVO paymentObj) {
		return process(paymentObj);
	}

	private String process(PaymentVO paymentObj) {
		PaymentDTO payment = new PaymentDTO();
		ResponseEntity<String> response = null;
		try {
			payment.setLastPaymentAmt(paymentObj.getPaymentAmt());
			payment.setCustomerId(paymentObj.getCustomerId());
			Map<String, Object> requestMap = new HashMap<String, Object>();
			requestMap.put("customerId", paymentObj.getCustomerId());
			requestMap.put("transAmt", paymentObj.getPaymentAmt());
			requestMap.put("transType", 3);
			HttpEntity<?> request = new HttpEntity<>(requestMap);
			try {
				response = restTemplate.exchange(billingAccountURI, HttpMethod.PUT, request, String.class);
				System.out.println(response.getBody().toString());
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
		} catch (Exception e) {
			logger.debug(e.getMessage(), e);
		}
		return response.getBody();
	}

}
